package my_Zoo;

import javax.swing.JComponent;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Graphics2D;

public class Cage {
	/*
	 * Cages�� �� ������ �츮�� ǥ���ϴ� ��ü
	 */
	private Point 		cagePoint;
	private Rectangle 	boundery;
	private Dimension	cageDimension;
	
	Cage(Point inputPoint)
	{
		/*
		 * cage�� ������
		 * ����:Point inputPoint
		 * exception:NullPointerException
		 */
	
		cagePoint = inputPoint;
		cageDimension = new Dimension(300,180);
		boundery = new Rectangle((int)inputPoint.getX(),(int)inputPoint.getY());
	}
	
}
