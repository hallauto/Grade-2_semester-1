package my_Zoo;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.Timer;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;

public class Screen {

}
