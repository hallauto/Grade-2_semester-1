package my_Zoo;

import java.awt.Point;

public class Tester{
	public static void main(String args[])
	{
		Point cagePoint = new Point(50,50);
		
	}
}
